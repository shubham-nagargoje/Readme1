import java.io.*;
import java.util.*;
class RDSPOP1
{
	static FileOutputStream fLitOut, fSymOut;
	RDSPOP1() 
	{
		try
		{
			fLitOut = new FileOutputStream("Literal Table.txt");
			fSymOut = new FileOutputStream("Symbol Table.txt");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args) throws Exception
	{
		new RDSPOP1();
		
		FileInputStream fin = new FileInputStream("Input.txt");
		FileOutputStream fout = new FileOutputStream("Output.txt");
		FileInputStream fopt = new FileInputStream("Operand Table.txt");
		FileOutputStream fPool = new FileOutputStream("Pool Table.txt");
		
		int x, loc = 0, pool = 1, symEnt = 1, litEnt = 1, inOpTab = 0;
		int pooltab[] = new int[10];
		
		for(int i=0; i<10; i=i+1)
			pooltab[i] = 0;
		pooltab[0] = 1;
		
		char c;
		String s = "", s2 = "", token = "", newString = "", finalString = "";
		String reg[] = new String[]{"areg","breg","creg","dreg"};
		
		while((x = fin.read()) != -1)
		{
			c = (char) x;
			s = s + c;
		}
		
		while((x = fopt.read()) != -1)
		{
			c = (char) x;
			s2 = s2 + c;
		}
		 
		StringTokenizer st = new StringTokenizer(s,", \n");
		while(st.hasMoreElements())
		{
			inOpTab = 0;
			token = st.nextToken();
			//System.out.println("Token : "+token);
			String code = "", cls = "";
			if(!(token.equalsIgnoreCase("end")))
			{
				StringTokenizer op = new StringTokenizer(s2);
				while(op.hasMoreElements())
				{
					int match = 0;
					String opToken = op.nextToken();
					if(opToken.equalsIgnoreCase(token))	//Token is present in Operand table
					{
						if((cls = op.nextToken()).equalsIgnoreCase("AD"))	//Assembler Directives
						{
							if(token.equalsIgnoreCase("start") || token.equalsIgnoreCase("origin"))	//Start or Origin Statement
							{
								code = op.nextToken();
								loc = Integer.parseInt(st.nextToken());
								String toWrite = "      ("+cls+","+code+")   (C,"+loc+")\n";
								byte b[] = toWrite.getBytes();
								fout.write(b);
								inOpTab = 1;
							}
							
							else if(token.equalsIgnoreCase("LTORG"))	//LTORG Statement
							{
								String poolWrite = "#" + pool + "\n";
								byte b[] = poolWrite.getBytes();
								fPool.write(b);
								String toWrite = String.valueOf(loc) + "   (AD, 05)\n";
								fout.write(toWrite.getBytes());								
								loc = LTORG(pool, fPool, loc);
								inOpTab = 1;
							}
							
							else if(token.equalsIgnoreCase("EQU"))	//EQU Statement
							{
								System.out.println("EQU");
								inOpTab = 1;
							}
						}
						
						else if(cls.equalsIgnoreCase("IS"))	//Imperative Statement
						{
							if(token.equalsIgnoreCase("Stop"))	//Stop statement
							{
								String toWrite = String.valueOf(loc) + "   (IS, 00)\n";
								fout.write(toWrite.getBytes());
								loc = loc + 1;
								inOpTab = 1;
							}
							else	//Not a stop statement
							{
								code = op.nextToken();
								String toWrite = String.valueOf(loc) + "   ("+cls+","+code+")";
								loc = loc + 1;
								token = st.nextToken();
								//System.out.println("token : "+token);
								for(int i=0;i<4;i=i+1)
									if(reg[i].equalsIgnoreCase(token))	//Checking for registers
									{
										match = 1;
										code = String.valueOf(i+1);
									}
								if(match == 1)	//Registers
								{
									toWrite = toWrite + "   " + code;
									token = st.nextToken();
									if(token.charAt(0) == '=')	//Literal
									{
										pool = literal(token, litEnt, fLitOut, fout, toWrite, pool, fPool);
										litEnt = litEnt + 1;
									}
									
									else	//Symbol
									{
										symbol(token, symEnt, fSymOut, fout, toWrite);
										symEnt = symEnt + 1; 
									}
									match = 0;
								}
								inOpTab = 1;
							}
						}
						
						else if(cls.equalsIgnoreCase("DL"))	//Declaration Statement
						{
							String constant = "";
							newString = "";
							finalString = "";
							if(token.equalsIgnoreCase("DC"))
								cls = "01";
							else if(token.equalsIgnoreCase("DS"))
								cls = "02";
							
							if(st.hasMoreElements())
								constant = st.nextToken();
							String toWrite = String.valueOf(loc) + "   (" + token.toUpperCase() + ", " + cls + ")   (C, " + constant + ")\n";
							fout.write(toWrite.getBytes());
									
							s = "";
							int time = 0;
							FileInputStream fSymIn = new FileInputStream("Symbol Table.txt");
							while((x = fSymIn.read()) != -1)
							{
								c = (char) x;
								s = s + c;
								if(c == '\n')
								{	
									if(time == 0 && s.endsWith("addressHere\n"))
									{
										newString = s.replace("addressHere", String.valueOf(loc));
										finalString = finalString + newString;
										loc = loc + 1;
										time = 1;
									}
									else
										finalString = finalString + s;				
									s = "";
								}
							}
							fSymOut.close();
							fSymOut = new FileOutputStream("Symbol Table.txt");
							fSymOut.write(finalString.getBytes());
							inOpTab = 1;
						}
					}
				}
				
				if(inOpTab == 0)	//Label
				{
					label(token, symEnt, fSymOut, loc);
					symEnt = symEnt + 1;
				}
			}
			
			else	//End statement
			{
				String toWrite = "      (AD, 02)\n";
				fout.write(toWrite.getBytes());
				FileInputStream fLitIn = new FileInputStream("Literal Table.txt");
				s = "";
				finalString = "";
				int time = 0;
				while((x = fLitIn.read()) != -1)
				{
					c = (char) x;
					s = s + c;
					if(c == '\n')
					{	
						if(time == 0 && s.endsWith("addressHere\n"))
						{
							newString = s.replace("addressHere", String.valueOf(loc));
							finalString = finalString + newString;
							loc = loc + 1;
							time = 1;
						}
						else
							finalString = finalString + s;				
						s = "";
					}
				}
				fLitOut.close();
				fLitOut = new FileOutputStream("Literal Table.txt");
				fLitOut.write(finalString.getBytes());
			}
		}
		System.out.println("Pass one completed !");
	}
	
	public static int LTORG(int pool, FileOutputStream fPool, int loc)throws Exception
	{
		String newString, finalString = "", s = "";
		char c;
		int x;
		FileInputStream fLitIn = new FileInputStream("Literal Table.txt");
		while((x = fLitIn.read()) != -1)
		{
			c = (char) x;
			s = s + c;
			if(c == '\n')
			{
				newString = s.replace("addressHere", ""+loc);
				finalString = finalString + newString;
				loc = loc + 1;
				s = "";
			}
		}
		fLitOut.close();
		fLitOut = new FileOutputStream("Literal Table.txt");
		fLitOut.write(finalString.getBytes());
		return loc;
	}
	
	public static void label(String token, int symEnt, FileOutputStream fSymOut, int loc)throws Exception
	{
		String s = "";
		int x, present = 0;
		char c;
		String toWrite = "", first = "", second = "";
		FileInputStream fSymIn = new FileInputStream("Symbol Table.txt");
		while((x = fSymIn.read()) != -1)
		{   
			c = (char) x;
			s = s + c;
		}
		StringTokenizer stSm = new StringTokenizer(s);
		
		while(stSm.hasMoreElements())
		{
			first = second;
			second = stSm.nextToken();
			if(stSm.hasMoreElements())
			{
				if(second.equalsIgnoreCase(token))
				{
					present = 1;
					System.out.println("Symbol \'"+token+"\' is already present in Symbol Table at position : "+first);
				}
			}
		}
		if(present == 0)	
		{
			String symWrite = String.valueOf(symEnt) + "   " + token + "   " + loc + "\n";
			byte symByte[] = symWrite.getBytes();	//Adding label to Symbol Table
			fSymOut.write(symByte);		
			//System.out.println("Added symbol "+token+" to symbol table at position : "+symEnt);
		}
	}
	
	public static void symbol(String token, int symEnt, FileOutputStream fSymOut, FileOutputStream fout, String toWrite)throws Exception
	{
		String s = "";
		int x, present = 0;
		String first = "", second = "";
		char c;
		FileInputStream fSymIn = new FileInputStream("Symbol Table.txt");
		while((x = fSymIn.read()) != -1)
		{
			c = (char) x;
			s = s + c;
		}
				
		StringTokenizer stSm = new StringTokenizer(s);
		while(stSm.hasMoreElements())
		{
			first = second;
			second = stSm.nextToken();
			if(stSm.hasMoreElements())
			{
				if(second.equalsIgnoreCase(token))
				{
					present = 1;
					System.out.println("Symbol \'"+token+"\' is already present in Symbol Table at position "+first);
					toWrite = toWrite + "   (S," + first + ")\n";
					byte b[] = toWrite.getBytes();
					fout.write(b);
				}
			}
		}
		if(present == 0)
		{
			String symWrite = String.valueOf(symEnt) + "   "+ token + "   addressHere\n";
			byte symByte[] = symWrite.getBytes();
			fSymOut.write(symByte);
			toWrite = toWrite + "   (S," + symEnt + ")\n";
			byte b[] = toWrite.getBytes();
			fout.write(b);
		}
	}
	
	public static int literal(String token, int litEnt, FileOutputStream fLitOut, FileOutputStream fout, String toWrite, int pool, FileOutputStream fPool)throws Exception
	{
		String s = "";
		int x, present = 0;
		String first = "", second = "";
		char c;
		FileInputStream fLitIn = new FileInputStream("Literal Table.txt");
		while((x = fLitIn.read()) != -1)
		{
			c = (char) x;
			s = s + c;
		}
		StringTokenizer stLt = new StringTokenizer(s);
		while(stLt.hasMoreElements())
		{
			first = second;
			second = stLt.nextToken();
			if(stLt.hasMoreElements())
			{
				if(second.equalsIgnoreCase(token))
				{
					present = 1;
					System.out.println("Literal \'"+token+"\' is already present in Literal Table at position "+first);
					toWrite = toWrite + "   (L," + first + ")\n";
					byte b[] = toWrite.getBytes();
					fout.write(b);
				}
			}
		}
		if(present == 0)
		{
			String litWrite = String.valueOf(litEnt) + "   "+ token + "   addressHere\n";
			byte litByte[] = litWrite.getBytes();
			fLitOut.write(litByte);
			toWrite = toWrite + "   (L," + litEnt + ")\n";
			byte b[] = toWrite.getBytes();
			fout.write(b);
			
			if(pool == 1)
			{
				String poolWrite = "#" + pool + "\n";
				b = poolWrite.getBytes();
				fPool.write(b);
			}
			pool = pool + 1;
		}
		return pool;
	}
}